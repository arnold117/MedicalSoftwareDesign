#include "cworker.h"

CWorker::CWorker(QObject *parent)
    : QObject{parent}
{

}
