#ifndef CDATACLASS_H
#define CDATACLASS_H


class CDataClass
{
public:
    CDataClass();
};

#endif // CDATACLASS_H
